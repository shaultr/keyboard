import style from './component.module.css'
import { useState } from 'react';
function Panel(){

}
export default Panel